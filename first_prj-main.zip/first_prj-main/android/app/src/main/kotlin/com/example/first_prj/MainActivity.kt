package com.example.first_prj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
